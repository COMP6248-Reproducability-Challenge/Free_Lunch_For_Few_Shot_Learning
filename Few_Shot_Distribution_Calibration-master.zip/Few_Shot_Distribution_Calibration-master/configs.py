save_dir                    = '.'
data_dir = {}
data_dir['CUB']             = './filelists/CUB/' 
data_dir['miniImagenet']    = './filelists/miniImagenet/' 
